import { GAME_WIDTH, GAME_HEIGHT } from "./constants.js";
import { Player } from "../entities/Player.js";
import { EnemySystem } from "../systems/EnemySystem.js";
import { CombatSystem, WEAPONS } from "../systems/CombatSystem.js";
import { ImageManager } from "../Managers/imagemanager.js";
import { Obstacle } from "../entities/Obstacle.js";

const SHOP_ITEMS = [
    { id: 'heal',  name: 'Potion', desc: 'Restore 30 HP',    icon: '❤️',  cost: 15 },
    { id: 'speed', name: 'Boost',  desc: '+10 move speed',   icon: '👟',  cost: 80 },
    { id: 'maxhp', name: 'Heart+', desc: '+20 max HP',        icon: '💗',  cost: 25 },
];

const CARD_BG = ['#1a3a5c', '#1a4a2c', '#3a1a4a'];

export class Game {
    constructor(canvas) {
        this.canvas = canvas;
        this.canvas.width = GAME_WIDTH;
        this.canvas.height = GAME_HEIGHT;
        this.ctx = canvas.getContext('2d');

        this.images = new ImageManager();
        this.keysDown = new Set();
        this.mouseX = 0;
        this.mouseY = 0;
        this.mouseClicked = false;
        this.savedCoins = 100;

        window.addEventListener('keydown', e => {
            this.keysDown.add(e.key);
            if (e.key === 'Escape') this.onEsc();
        });
        window.addEventListener('keyup', e => this.keysDown.delete(e.key));
        canvas.addEventListener('mousemove', e => {
            const r = canvas.getBoundingClientRect();
            this.mouseX = (e.clientX - r.left) * (GAME_WIDTH / r.width);
            this.mouseY = (e.clientY - r.top) * (GAME_HEIGHT / r.height);
        });
        canvas.addEventListener('click', () => { this.mouseClicked = true; });

        this.state = 'loading';
        this.player = null;
        this.enemySystem = null;
        this.combatSystem = null;
        this.obstacles = [];
        this.paused = false;
        this.levelUpChoices = [];
        this.shopOpen = false;
        this.lastTime = 0;

        this.images.loadAll().then(() => {
            this.state = 'title';
            this.lastTime = performance.now();
            requestAnimationFrame(t => this.loop(t));
        });
    }

    start() {}

    onEsc() {
        if (this.state === 'playing') this.paused = !this.paused;
    }

    startGame() {
        this.player = new Player(GAME_WIDTH / 2 - 24, GAME_HEIGHT / 2 - 24);
        this.player.coins = this.savedCoins;
        this.enemySystem = new EnemySystem();
        this.combatSystem = new CombatSystem();
        this.obstacles = this.generateObstacles();
        this.paused = false;
        this.levelUpChoices = [];
        this.shopOpen = false;
        this.state = 'playing';
    }

    generateObstacles() {
        const types = ['rock', 'tree', 'water'];
        const obs = [];
        for (let i = 0; i < 12; i++) {
            const t = types[Math.floor(Math.random() * types.length)];
            obs.push(new Obstacle(t,
                80 + Math.random() * (GAME_WIDTH - 200),
                80 + Math.random() * (GAME_HEIGHT - 200)
            ));
        }
        return obs;
    }

    loop(timestamp) {
        const dt = Math.min((timestamp - this.lastTime) / 1000, 0.05);
        this.lastTime = timestamp;
        if (this.state === 'playing') this.update(dt);
        this.render();
        this.mouseClicked = false;
        requestAnimationFrame(t => this.loop(t));
    }

    update(dt) {
        if (this.paused || this.levelUpChoices.length > 0 || this.shopOpen) return;
        this.player.update(dt, this.keysDown);
        this.enemySystem.allWeaponsOwned = this.combatSystem.getOwnedIds().length >= Object.values(WEAPONS).length;
        this.enemySystem.update(dt, this.player);
        this.combatSystem.update(dt, this.player, this.enemySystem);
        if (this.combatSystem.pendingLevelUp) {
            this.combatSystem.pendingLevelUp = false;
            this.offerLevelUpChoices();
        }
        if (this.player.dead) {
            this.savedCoins = this.player.coins;
            this.state = 'gameover';
        }
    }

    offerLevelUpChoices() {
        const owned = this.combatSystem.getOwnedIds();
        const all = Object.values(WEAPONS);
        const unowned = all.filter(w => !owned.includes(w.id));
        const pool = unowned.length >= 3 ? unowned : all;
        this.levelUpChoices = [...pool].sort(() => Math.random() - 0.5).slice(0, 3);
    }

    render() {
        const ctx = this.ctx;
        if (this.state === 'loading') {
            ctx.fillStyle = '#0d0d1a';
            ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
            ctx.fillStyle = '#fff';
            ctx.font = '24px monospace';
            ctx.textAlign = 'center';
            ctx.fillText('Loading...', GAME_WIDTH / 2, GAME_HEIGHT / 2);
            return;
        }
        if (this.state === 'title')   { this.renderTitle();   return; }
        if (this.state === 'gameover'){ this.renderGameOver(); return; }
        if (this.state === 'shop')    { this.renderShop();    return; }

        this.renderGame();
        if (this.levelUpChoices.length > 0) this.renderLevelUp();
        else if (this.shopOpen) this.renderShop();
        else if (this.paused)   this.renderPause();
    }

    renderTitle() {
        const ctx = this.ctx;
        ctx.fillStyle = '#0d0d1a';
        ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

        const bw = 300, bh = 220, bx = GAME_WIDTH / 2 - bw / 2, by = GAME_HEIGHT / 2 - bh / 2;
        ctx.strokeStyle = '#3a9efd';
        ctx.lineWidth = 2;
        ctx.strokeRect(bx, by, bw, bh);

        ctx.fillStyle = '#ffcc00';
        ctx.font = 'bold 26px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('Pikachu Survivor', GAME_WIDTH / 2, by + 48);
        ctx.fillStyle = '#aaa';
        ctx.font = '13px monospace';
        ctx.fillText('Throw bolts, level up, defeat all!', GAME_WIDTH / 2, by + 76);

        const playHover = this.inBox(bx + 30, by + 108, 100, 36);
        ctx.fillStyle = playHover ? '#3a9efd' : '#1a5a9e';
        ctx.fillRect(bx + 30, by + 108, 100, 36);
        ctx.fillStyle = '#fff';
        ctx.font = '16px monospace';
        ctx.fillText('PLAY', bx + 80, by + 131);

        const shopHover = this.inBox(bx + 168, by + 108, 100, 36);
        ctx.fillStyle = shopHover ? '#3a9efd' : '#1a5a9e';
        ctx.fillRect(bx + 168, by + 108, 100, 36);
        ctx.fillStyle = '#fff';
        ctx.fillText('SHOP', bx + 218, by + 131);

        ctx.fillStyle = '#ffd700';
        ctx.font = '14px monospace';
        ctx.fillText('Coins: ' + this.savedCoins, GAME_WIDTH / 2, by + 168);
        ctx.fillStyle = '#555';
        ctx.font = '12px monospace';
        ctx.fillText('WASD - Move    ESC - Pause', GAME_WIDTH / 2, by + 195);

        if (this.mouseClicked) {
            if (playHover) this.startGame();
            else if (shopHover) this.state = 'shop';
        }
        ctx.textAlign = 'left';
    }

    renderGame() {
        const ctx = this.ctx;

        ctx.fillStyle = '#0d1a2e';
        ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
        ctx.strokeStyle = '#1a2a4a';
        ctx.lineWidth = 1;
        for (let x = 0; x < GAME_WIDTH; x += 64) {
            ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, GAME_HEIGHT); ctx.stroke();
        }
        for (let y = 0; y < GAME_HEIGHT; y += 64) {
            ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(GAME_WIDTH, y); ctx.stroke();
        }

        for (const obs of this.obstacles) {
            const img = this.images.get(obs.type);
            if (img) ctx.drawImage(img, obs.x, obs.y, obs.width, obs.height);
            else {
                ctx.fillStyle = obs.type === 'water' ? '#2255aa' : obs.type === 'tree' ? '#1a5c1a' : '#5c3a1a';
                ctx.fillRect(obs.x, obs.y, obs.width, obs.height);
            }
        }

        for (const e of this.enemySystem.enemies) {
            const img = this.images.get(e.type);
            if (img) ctx.drawImage(img, e.x, e.y, e.width, e.height);
            else {
                ctx.fillStyle = e.type === 'bat' ? '#7b3f9e' : '#cc3333';
                ctx.fillRect(e.x, e.y, e.width, e.height);
            }
            if (e.health < e.maxHealth) {
                ctx.fillStyle = '#333';
                ctx.fillRect(e.x, e.y - 10, e.width, 5);
                ctx.fillStyle = '#e74c3c';
                ctx.fillRect(e.x, e.y - 10, e.width * (e.health / e.maxHealth), 5);
            }
        }

        for (const p of this.combatSystem.projectiles) {
            const img = this.images.get('projectile');
            if (img) ctx.drawImage(img, p.x, p.y, p.width, p.height);
            else {
                ctx.fillStyle = p.kind === 'voltBomb' ? '#ff6600' : '#ffe066';
                ctx.beginPath();
                ctx.arc(p.x + p.width / 2, p.y + p.height / 2, p.width / 2, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        const playerImg = this.images.get('knight');
        const pl = this.player;
        if (playerImg) ctx.drawImage(playerImg, pl.x, pl.y, pl.width, pl.height);
        else {
            ctx.fillStyle = '#ffcc00';
            ctx.fillRect(pl.x, pl.y, pl.width, pl.height);
        }

        this.renderHUD();
    }

    renderHUD() {
        const ctx = this.ctx;
        const p = this.player;
        const pad = 12;

        // HP bar — top left
        ctx.fillStyle = '#111';
        ctx.fillRect(pad, pad, 220, 16);
        ctx.fillStyle = '#e74c3c';
        ctx.fillRect(pad, pad, 220 * (p.hp / p.maxHp), 16);
        ctx.fillStyle = '#fff';
        ctx.font = '11px monospace';
        ctx.textAlign = 'left';
        ctx.fillText(`HP ${Math.ceil(p.hp)}/${p.maxHp}`, pad + 4, pad + 12);

        // coins — top left below HP
        ctx.fillStyle = '#ffd700';
        ctx.font = '13px monospace';
        ctx.fillText(`Coins: ${p.coins}`, pad, pad + 38);

        // weapons — top right
        ctx.textAlign = 'right';
        ctx.fillStyle = '#ccc';
        ctx.font = '12px monospace';
        const wlist = this.combatSystem.activeWeapons.map(w => w.icon + ' ' + w.name).join('   ');
        ctx.fillText(wlist, GAME_WIDTH - pad, pad + 14);
        ctx.textAlign = 'left';

        // XP bar — bottom center, big
        const xpW = 500, xpH = 24, xpX = GAME_WIDTH / 2 - xpW / 2, xpY = GAME_HEIGHT - 44;
        ctx.fillStyle = '#111';
        ctx.fillRect(xpX, xpY, xpW, xpH);
        ctx.fillStyle = '#3a9efd';
        ctx.fillRect(xpX, xpY, xpW * (p.xp / p.xpToNext), xpH);
        ctx.strokeStyle = '#3a9efd';
        ctx.lineWidth = 2;
        ctx.strokeRect(xpX, xpY, xpW, xpH);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 13px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(`Lv ${p.level}   ${p.xp} / ${p.xpToNext} XP`, GAME_WIDTH / 2, xpY + 16);
        ctx.textAlign = 'left';
    }

    renderLevelUp() {
        const ctx = this.ctx;
        ctx.fillStyle = 'rgba(0,0,0,0.72)';
        ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

        ctx.fillStyle = '#ffd700';
        ctx.font = 'bold 28px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('LEVEL UP!  Pick a weapon:', GAME_WIDTH / 2, 155);

        const cardW = 200, cardH = 145, gap = 24;
        const startX = GAME_WIDTH / 2 - (cardW * 3 + gap * 2) / 2;
        const cardY = 185;

        this.levelUpChoices.forEach((w, i) => {
            const cx = startX + i * (cardW + gap);
            const hover = this.inBox(cx, cardY, cardW, cardH);

            ctx.fillStyle = hover ? '#2a5a8c' : CARD_BG[i];
            ctx.strokeStyle = hover ? '#ffd700' : '#3a9efd';
            ctx.lineWidth = 2;
            ctx.fillRect(cx, cardY, cardW, cardH);
            ctx.strokeRect(cx, cardY, cardW, cardH);

            ctx.textAlign = 'center';
            ctx.fillStyle = '#fff';
            ctx.font = '28px monospace';
            ctx.fillText(w.icon, cx + cardW / 2, cardY + 42);
            ctx.font = 'bold 14px monospace';
            ctx.fillText(w.name, cx + cardW / 2, cardY + 68);
            ctx.fillStyle = '#aaa';
            ctx.font = '11px monospace';
            ctx.fillText(w.desc, cx + cardW / 2, cardY + 90);
            ctx.fillStyle = '#ffd700';
            ctx.fillText(`DMG ${w.damage}  SPD ${w.speed}`, cx + cardW / 2, cardY + 115);

            if (hover && this.mouseClicked) {
                this.combatSystem.addWeapon(w.id);
                this.levelUpChoices = [];
            }
        });
        ctx.textAlign = 'left';
    }

    renderShop() {
        const ctx = this.ctx;
        const coins = this.state === 'playing' ? this.player.coins : this.savedCoins;

        ctx.fillStyle = '#0d0d1a';
        ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
        ctx.fillStyle = '#ffd700';
        ctx.font = 'bold 26px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(`SHOP   Coins: ${coins}`, GAME_WIDTH / 2, 90);

        SHOP_ITEMS.forEach((item, i) => {
            const bx = GAME_WIDTH / 2 - 160, by = 130 + i * 80;
            const hover = this.inBox(bx, by, 320, 62);
            const canAfford = coins >= item.cost;

            ctx.fillStyle = hover && canAfford ? '#2a5a2a' : '#141414';
            ctx.strokeStyle = canAfford ? '#3a9e3a' : '#444';
            ctx.lineWidth = 2;
            ctx.fillRect(bx, by, 320, 62);
            ctx.strokeRect(bx, by, 320, 62);

            ctx.font = '22px monospace';
            ctx.textAlign = 'left';
            ctx.fillStyle = canAfford ? '#fff' : '#555';
            ctx.fillText(item.icon, bx + 14, by + 40);
            ctx.font = 'bold 14px monospace';
            ctx.fillText(item.name, bx + 54, by + 24);
            ctx.fillStyle = '#888';
            ctx.font = '12px monospace';
            ctx.fillText(item.desc, bx + 54, by + 44);
            ctx.fillStyle = '#ffd700';
            ctx.font = 'bold 14px monospace';
            ctx.textAlign = 'right';
            ctx.fillText(`${item.cost} coins`, bx + 312, by + 36);

            if (hover && this.mouseClicked && canAfford) {
                if (this.state === 'playing') {
                    if (item.id === 'heal')  this.player.hp = Math.min(this.player.maxHp, this.player.hp + 30);
                    if (item.id === 'speed') this.player.speed = Math.min(320, this.player.speed + 10);
                    if (item.id === 'maxhp') { this.player.maxHp += 20; this.player.hp = Math.min(this.player.hp + 20, this.player.maxHp); }
                    this.player.coins -= item.cost;
                } else {
                    this.savedCoins -= item.cost;
                }
            }
        });

        const closeHover = this.inBox(GAME_WIDTH / 2 - 70, 400, 140, 38);
        ctx.fillStyle = closeHover ? '#5a1a1a' : '#2a0a0a';
        ctx.strokeStyle = '#e74c3c';
        ctx.lineWidth = 2;
        ctx.fillRect(GAME_WIDTH / 2 - 70, 400, 140, 38);
        ctx.strokeRect(GAME_WIDTH / 2 - 70, 400, 140, 38);
        ctx.fillStyle = '#e74c3c';
        ctx.font = '15px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('CLOSE', GAME_WIDTH / 2, 425);

        if (closeHover && this.mouseClicked) {
            if (this.state === 'playing') this.shopOpen = false;
            else this.state = 'title';
        }
        ctx.textAlign = 'left';
    }

    renderPause() {
        const ctx = this.ctx;
        ctx.fillStyle = 'rgba(0,0,0,0.55)';
        ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 40px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('PAUSED', GAME_WIDTH / 2, GAME_HEIGHT / 2 - 30);

        const shopHover = this.inBox(GAME_WIDTH / 2 - 65, GAME_HEIGHT / 2 + 10, 130, 38);
        ctx.fillStyle = shopHover ? '#3a9efd' : '#1a5a9e';
        ctx.fillRect(GAME_WIDTH / 2 - 65, GAME_HEIGHT / 2 + 10, 130, 38);
        ctx.fillStyle = '#fff';
        ctx.font = '16px monospace';
        ctx.fillText('SHOP', GAME_WIDTH / 2, GAME_HEIGHT / 2 + 35);
        if (shopHover && this.mouseClicked) this.shopOpen = true;

        ctx.fillStyle = '#666';
        ctx.font = '13px monospace';
        ctx.fillText('ESC to resume', GAME_WIDTH / 2, GAME_HEIGHT / 2 + 78);
        ctx.textAlign = 'left';
    }

    renderGameOver() {
        const ctx = this.ctx;
        ctx.fillStyle = '#0d0d1a';
        ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
        ctx.fillStyle = '#e74c3c';
        ctx.font = 'bold 52px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('GAME OVER', GAME_WIDTH / 2, GAME_HEIGHT / 2 - 70);
        ctx.fillStyle = '#aaa';
        ctx.font = '18px monospace';
        ctx.fillText(`Level ${this.player.level}   Coins: ${this.player.coins}`, GAME_WIDTH / 2, GAME_HEIGHT / 2 - 20);

        const retryHover = this.inBox(GAME_WIDTH / 2 - 90, GAME_HEIGHT / 2 + 20, 180, 40);
        ctx.fillStyle = retryHover ? '#c0392b' : '#5a1a1a';
        ctx.fillRect(GAME_WIDTH / 2 - 90, GAME_HEIGHT / 2 + 20, 180, 40);
        ctx.fillStyle = '#fff';
        ctx.font = '18px monospace';
        ctx.fillText('PLAY AGAIN', GAME_WIDTH / 2, GAME_HEIGHT / 2 + 46);

        if (retryHover && this.mouseClicked) this.state = 'title';
        ctx.textAlign = 'left';
    }

    inBox(x, y, w, h) {
        return this.mouseX >= x && this.mouseX <= x + w &&
               this.mouseY >= y && this.mouseY <= y + h;
    }
}
