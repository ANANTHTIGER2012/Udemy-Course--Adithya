import { Enemy } from '../entities/Enemy.js';
import { GAME_WIDTH, GAME_HEIGHT } from '../Core/constants.js';

export class EnemySystem {
    constructor() {
        this.enemies = [];
        this.spawnTimer = 0;
        this.spawnInterval = 1.2;
        this.allWeaponsOwned = false;
    }

    reset() {
        this.enemies = [];
        this.spawnTimer = 0;
        this.spawnInterval = 1.2;
        this.allWeaponsOwned = false;
    }

    update(dt, player) {
        this.spawnTimer += dt;
        const minInterval = this.allWeaponsOwned ? 0.25 : 0.65;
        if (this.spawnTimer >= this.spawnInterval) {
            this.spawnTimer = 0;
            const count = this.allWeaponsOwned
                ? (Math.random() < 0.5 ? 3 : 2)
                : (Math.random() < 0.35 ? 2 : 1);
            for (let i = 0; i < count; i++) this.spawnEnemy();
            this.spawnInterval = Math.max(minInterval, this.spawnInterval - 0.015);
        }

        for (const e of this.enemies) e.update(dt, player);
        this.enemies = this.enemies.filter(e => !e.dead);
    }

    spawnEnemy() {
        const type = Math.random() < 0.65 ? 'bat' : 'eyeball';
        const side = Math.floor(Math.random() * 4);
        let x, y;
        switch (side) {
            case 0: x = Math.random() * GAME_WIDTH; y = -80; break;
            case 1: x = GAME_WIDTH + 80; y = Math.random() * GAME_HEIGHT; break;
            case 2: x = Math.random() * GAME_WIDTH; y = GAME_HEIGHT + 80; break;
            default: x = -80; y = Math.random() * GAME_HEIGHT;
        }
        this.enemies.push(new Enemy(type, x, y));
    }
}
