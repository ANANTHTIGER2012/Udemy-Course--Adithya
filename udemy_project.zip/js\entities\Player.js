import { GAME_WIDTH, GAME_HEIGHT } from "../Core/constants.js";

export class Player {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = 48;
        this.height = 48;
        this.speed = 180;
        this.hp = 100;
        this.maxHp = 100;
        this.xp = 0;
        this.xpToNext = 80;
        this.level = 1;
        this.coins = 0;
        this.dead = false;
    }

    update(dt, keys) {
        let dx = 0, dy = 0;
        if (keys.has('ArrowLeft') || keys.has('a')) dx -= 1;
        if (keys.has('ArrowRight') || keys.has('d')) dx += 1;
        if (keys.has('ArrowUp') || keys.has('w')) dy -= 1;
        if (keys.has('ArrowDown') || keys.has('s')) dy += 1;

        if (dx !== 0 && dy !== 0) { dx *= 0.707; dy *= 0.707; }

        this.x += dx * this.speed * dt;
        this.y += dy * this.speed * dt;

        this.x = Math.max(0, Math.min(GAME_WIDTH - this.width, this.x));
        this.y = Math.max(0, Math.min(GAME_HEIGHT - this.height, this.y));
    }

    gainXp(amount) {
        this.xp += amount;
        if (this.xp >= this.xpToNext) {
            this.xp -= this.xpToNext;
            this.xpToNext = Math.floor(this.xpToNext * 1.6);
            this.level++;
            return true;
        }
        return false;
    }

    takeDamage(amount) {
        this.hp -= amount;
        if (this.hp <= 0) { this.hp = 0; this.dead = true; }
    }
}
