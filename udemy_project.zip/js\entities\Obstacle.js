const SIZES = {
    rock:  { width: 64,  height: 48  },
    tree:  { width: 64,  height: 96  },
    water: { width: 160, height: 112 },
};

export class Obstacle {
    constructor(type, x, y) {
        this.type = type;
        this.x = x;
        this.y = y;
        const s = SIZES[type] || SIZES.rock;
        this.width = s.width;
        this.height = s.height;
    }
}
