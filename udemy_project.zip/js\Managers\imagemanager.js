export class ImageManager {
    constructor() {
        this.images = {};
    }

    load(name, path) {
        return new Promise((resolve) => {
            const img = new Image();
            img.src = path;
            this.images[name] = { img, loaded: false };
            img.onload = () => { this.images[name].loaded = true; resolve(); };
            img.onerror = () => { console.log(`Image failed: ${name} (will use fallback)`); resolve(); };
        });
    }

    get(name) {
        return this.images[name]?.loaded ? this.images[name].img : null;
    }

    async loadAll() {
        await Promise.all([
            this.load('goku',       './Images/goku.png'),
            this.load('bat',        './Images/player.png'),
            this.load('frieza',     './Images/frieza.png'),
            this.load('rock',       './Images/rock.png'),
            this.load('tree',       './Images/tree.png'),
            this.load('projectile', './Images/projectile.png'),
            this.load('water',      './Images/water.png'),
        ]);
    }
}
