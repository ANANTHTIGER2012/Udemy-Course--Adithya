﻿export const GAME_WIDTH = 1024;
export const GAME_HEIGHT = 576;
export const CANVAS_WIDTH = GAME_WIDTH;
export const CANVAS_HEIGHT = GAME_HEIGHT;
