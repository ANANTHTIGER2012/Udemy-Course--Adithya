export class Enemy {
    constructor(type, x, y) {
        this.type = type;
        this.x = x;
        this.y = y;

        if (type === 'frieza') {
            this.width = 48;
            this.height = 48;
            this.speed = 130 + Math.random() * 60;
            this.maxHealth = 30;
            this.damage = 8;
            this.coinReward = 2;
            this.xpReward = 8;
        } else if (type === 'bat') {
            this.width = 64;
            this.height = 64;
            this.speed = 90 + Math.random() * 50;
            this.maxHealth = 40;
            this.damage = 12;
            this.coinReward = 2;
            this.xpReward = 10;
        } else {
            this.width = 40;
            this.height = 40;
            this.speed = 150 + Math.random() * 60;
            this.maxHealth = 20;
            this.damage = 6;
            this.coinReward = 1;
            this.xpReward = 5;
        }

        this.health = this.maxHealth;
        this.dead = false;
    }

    update(dt, player) {
        const cx = this.x + this.width / 2;
        const cy = this.y + this.height / 2;
        const px = player.x + player.width / 2;
        const py = player.y + player.height / 2;
        const dx = px - cx, dy = py - cy;
        const len = Math.sqrt(dx * dx + dy * dy);
        if (len > 1) {
            this.x += (dx / len) * this.speed * dt;
            this.y += (dy / len) * this.speed * dt;
        }
    }

    takeDamage(amount) {
        this.health -= amount;
        if (this.health <= 0) this.dead = true;
    }
}
