﻿import { CANVAS_WIDTH, CANVAS_HEIGHT } from "../Core/constants.js";

export class RenderSystem {
  constructor(ctx) {
    this.ctx = ctx;
  }

  clear(w, h) {
    this.ctx.clearRect(0, 0, w, h);
  }

  drawBackground() {
    const ctx = this.ctx;
    const grad = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT);
    grad.addColorStop(0, "#1a1a2e");
    grad.addColorStop(1, "#16213e");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    ctx.fillStyle = "#2c2c54";
    ctx.fillRect(0, GROUND_Y + 80, CANVAS_WIDTH, CANVAS_HEIGHT);

    ctx.strokeStyle = "#e94560";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, GROUND_Y + 80);
    ctx.lineTo(CANVAS_WIDTH, GROUND_Y + 80);
    ctx.stroke();
  }

  drawPlayer(player) {
    const ctx = this.ctx;
    ctx.fillStyle = player.isAttacking ? "#fff" : player.color;
    ctx.fillRect(player.x, player.y, player.width, player.height);

    ctx.fillStyle = "#fff";
    ctx.fillRect(player.x + 10, player.y + 10, 10, 10);
    ctx.fillRect(player.x + 30, player.y + 10, 10, 10);
  }

  drawHUD(p1, p2) {
    const ctx = this.ctx;
    const barW = 300;
    const barH = 20;
    const pad = 20;

    ctx.fillStyle = "#555";
    ctx.fillRect(pad, pad, barW, barH);
    ctx.fillStyle = "#e74c3c";
    ctx.fillRect(pad, pad, barW * (p1.hp / 100), barH);

    ctx.fillStyle = "#555";
    ctx.fillRect(CANVAS_WIDTH - pad - barW, pad, barW, barH);
    ctx.fillStyle = "#3498db";
    ctx.fillRect(CANVAS_WIDTH - pad - barW * (p2.hp / 100), pad, barW * (p2.hp / 100), barH);

    ctx.fillStyle = "#fff";
    ctx.font = "14px monospace";
    ctx.fillText("P1", pad, pad + barH + 16);
    ctx.textAlign = "right";
    ctx.fillText("P2", CANVAS_WIDTH - pad, pad + barH + 16);
    ctx.textAlign = "left";
  }
}
