import { GAME_WIDTH, GAME_HEIGHT } from "../Core/constants.js";

export class Projectile {
    constructor(x, y, dx, dy, speed, damage) {
        this.x = x;
        this.y = y;
        this.dx = dx;
        this.dy = dy;
        this.speed = speed;
        this.damage = damage;
        this.width = 14;
        this.height = 14;
        this.dead = false;
    }

    update(dt) {
        this.x += this.dx * this.speed * dt;
        this.y += this.dy * this.speed * dt;
        if (this.x < -60 || this.x > GAME_WIDTH + 60 || this.y < -60 || this.y > GAME_HEIGHT + 60) {
            this.dead = true;
        }
    }
}
