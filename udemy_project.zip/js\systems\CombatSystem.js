import { Projectile } from '../entities/Projectile.js';

function findNearest(player, enemies) {
    const px = player.x + player.width / 2;
    const py = player.y + player.height / 2;
    let nearest = null, best = Infinity;
    for (const e of enemies) {
        if (e.dead) continue;
        const d = Math.hypot(e.x + e.width / 2 - px, e.y + e.height / 2 - py);
        if (d < best) { best = d; nearest = e; }
    }
    return nearest;
}

function angleToEnemy(player, enemy) {
    const px = player.x + player.width / 2;
    const py = player.y + player.height / 2;
    return Math.atan2(enemy.y + enemy.height / 2 - py, enemy.x + enemy.width / 2 - px);
}

function makeProj(player, angle, speed, damage, size = 18, kind = 'thundershock') {
    const px = player.x + player.width / 2 - size / 2;
    const py = player.y + player.height / 2 - size / 2;
    const p = new Projectile(px, py, Math.cos(angle), Math.sin(angle), speed, damage);
    p.width = size;
    p.height = size;
    p.kind = kind;
    return p;
}

export const WEAPONS = {
    thundershock: {
        id: 'thundershock',
        name: 'Thunder Shock',
        desc: 'Electric ball hits the nearest foe',
        icon: '⚡',
        interval: 0.45,
        damage: 12,
        speed: 500,
        fire(player, enemies) {
            const e = findNearest(player, enemies);
            if (!e) return [];
            return [makeProj(player, angleToEnemy(player, e), this.speed, this.damage, 18, 'thundershock')];
        }
    },
    dualSpark: {
        id: 'dualSpark',
        name: 'Dual Spark',
        desc: 'Two bolts in a V-spread',
        icon: '⚡⚡',
        interval: 0.5,
        damage: 9,
        speed: 470,
        fire(player, enemies) {
            const e = findNearest(player, enemies);
            if (!e) return [];
            const a = angleToEnemy(player, e);
            return [makeProj(player, a - 0.25, this.speed, this.damage, 18, 'dualSpark'), makeProj(player, a + 0.25, this.speed, this.damage, 18, 'dualSpark')];
        }
    },
    tripleThunder: {
        id: 'tripleThunder',
        name: 'Triple Thunder',
        desc: 'Three bolts in a wide spread',
        icon: '⚡⚡⚡',
        interval: 0.65,
        damage: 8,
        speed: 450,
        fire(player, enemies) {
            const e = findNearest(player, enemies);
            if (!e) return [];
            const a = angleToEnemy(player, e);
            return [
                makeProj(player, a - 0.4, this.speed, this.damage, 18, 'tripleThunder'),
                makeProj(player, a,       this.speed, this.damage, 18, 'tripleThunder'),
                makeProj(player, a + 0.4, this.speed, this.damage, 18, 'tripleThunder'),
            ];
        }
    },
    ringBolt: {
        id: 'ringBolt',
        name: 'Ring Bolt',
        desc: 'Electric burst in all 8 directions',
        icon: '🔮',
        interval: 1.8,
        damage: 15,
        speed: 380,
        fire(player) {
            return Array.from({ length: 8 }, (_, i) =>
                makeProj(player, (Math.PI * 2 * i) / 8, this.speed, this.damage, 18, 'ringBolt')
            );
        }
    },
    rapidZap: {
        id: 'rapidZap',
        name: 'Rapid Zap',
        desc: 'Blazing fast single shots',
        icon: '💨',
        interval: 0.16,
        damage: 6,
        speed: 620,
        fire(player, enemies) {
            const e = findNearest(player, enemies);
            if (!e) return [];
            return [makeProj(player, angleToEnemy(player, e), this.speed, this.damage, 12, 'rapidZap')];
        }
    },
    voltBomb: {
        id: 'voltBomb',
        name: 'Volt Bomb',
        desc: 'Slow heavy blast, massive damage',
        icon: '💣',
        interval: 1.3,
        damage: 45,
        speed: 240,
        fire(player, enemies) {
            const e = findNearest(player, enemies);
            if (!e) return [];
            return [makeProj(player, angleToEnemy(player, e), this.speed, this.damage, 28, 'voltBomb')];
        }
    },
};

function overlaps(a, b) {
    return a.x < b.x + b.width && a.x + a.width > b.x &&
           a.y < b.y + b.height && a.y + a.height > b.y;
}

export class CombatSystem {
    constructor() {
        this.projectiles = [];
        this.activeWeapons = [{ ...WEAPONS.thundershock, timer: 0 }];
        this.pendingLevelUp = false;
    }

    reset() {
        this.projectiles = [];
        this.activeWeapons = [{ ...WEAPONS.thundershock, timer: 0 }];
        this.pendingLevelUp = false;
    }

    addWeapon(id) {
        if (!this.activeWeapons.find(w => w.id === id)) {
            this.activeWeapons.push({ ...WEAPONS[id], timer: 0 });
        }
    }

    getOwnedIds() {
        return this.activeWeapons.map(w => w.id);
    }

    update(dt, player, enemySystem) {
        for (const weapon of this.activeWeapons) {
            weapon.timer += dt;
            if (weapon.timer >= weapon.interval && enemySystem.enemies.length > 0 && !player.dead) {
                weapon.timer = 0;
                this.projectiles.push(...weapon.fire(player, enemySystem.enemies));
            }
        }

        for (const p of this.projectiles) p.update(dt);

        for (const proj of this.projectiles) {
            if (proj.dead) continue;
            for (const enemy of enemySystem.enemies) {
                if (enemy.dead) continue;
                if (overlaps(proj, enemy)) {
                    proj.dead = true;
                    enemy.takeDamage(proj.damage);
                    if (enemy.dead) {
                        player.coins += enemy.coinReward;
                        if (player.gainXp(enemy.xpReward)) this.pendingLevelUp = true;
                    }
                    break;
                }
            }
        }

        for (const enemy of enemySystem.enemies) {
            if (!enemy.dead && overlaps(player, enemy)) {
                player.takeDamage(enemy.damage * dt);
            }
        }

        this.projectiles = this.projectiles.filter(p => !p.dead);
    }
}
